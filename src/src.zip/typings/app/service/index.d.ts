// This file is created by egg-ts-helper@1.25.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportReadjson = require('../../../app/service/readjson');

declare module 'egg' {
  interface IService {
    readjson: ExportReadjson;
  }
}
